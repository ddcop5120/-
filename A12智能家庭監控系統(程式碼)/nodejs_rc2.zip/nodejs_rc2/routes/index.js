// javascript和C一樣使用//表示單行註解，使用/* */表示多行註解
// 載入express模組 
var express = require('express');
/* 使用express.Router類別來建立可裝載的模組路由的物件
   路由是指應用程式端點 (URI) 的定義，以及應用程式如何回應用戶端的要求。*/
var router = express.Router();

// 載入serialport模組並建立串列埠物件serialport (預設serial port也會被打開)
var com = require('serialport');
var serialport = new com.SerialPort("/dev/ttyACM0",{
	baudrate: 9600,  // 設定串列埠之傳輸速度為9600 bit/sec
	parser: com.parsers.readline("\n") // 設定列的結束符號為\n
	}, function (err) {
		if (err) 
			console.log('Error: ', err.message);
		else
			console.log("Serial Port is opened"); 
    });

// 載入request, querystring, serialport模組
var request = require('request');
var querystring = require('querystring');


// 取得Server端的ip，請記得在專案中安裝underscore模組: npm install underscore
var sip = require('underscore')
    .chain(require('os').networkInterfaces())
    .values()
    .flatten()
    .find({family: 'IPv4', internal: false})
    .value()
    .address;
console.log('Server IP='+sip);
// 建造傳回給各網頁(.ejs)的伺服器ip物件，分成4部分:
//<例如：server ip=10.0.2.205，則serverip0=10, serverip1=0, serverip2=2, serverip3=205  -->
sip_array = sip.split('.');
reply_obj = {serverip0: sip_array[0], serverip1: sip_array[1], serverip2: sip_array[2], serverip3: sip_array[3]};

// 建立Web Video Streaming的狀態儲存檔wvs_status.txt(初始值為off)
fs = require('fs');
fs.writeFileSync('./wvs-status.txt', 'off');
console.log('The wvs-status.txt is created!');

// 建立Web Video Streaming的pid儲存檔wvs_pid.txt(初始值為0)
fs = require('fs');
fs.writeFileSync('./wvs-pid.txt', '0');
console.log('The wvs-pid.txt is created!');

//**************************************************************************
//************ 根據Client端送來之請求命令顯示相對應網頁之方法 ************
//**************************************************************************
// 建立(附加)一個客戶端對應用程式提出 GET / 方法時的路由處理方法(匿名式函數)
// 比照此方式，你可以建立其他GET不同路徑的路由處理方法
// 顯示首頁
serverip_obj = {serverip:sip};
router.get('/', function(req, res) {
	res.render('index');
});

// 顯示數學服務操作介面
router.get('/math', function(req, res) {
	res.render('math');
});

// 顯示樂透服務操作介面
router.get('/lottery', function(req, res) {
	res.render('lottery');
});

// 顯示天氣查詢服務操作介面
router.get('/weather', function(req, res) {
	res.render('weather');
});

// 顯示遠端監控服務操作介面
router.get('/remotecontrol', function(req, res) {

	// 讓遠端監控網頁載入時，就顯示影像串流
	// 讀取Web Video Streaming的狀態
	fs=require('fs');
    wvs_status = fs.readFileSync('./wvs-status.txt','utf8'); 
	
    // 若影像串流關閉著，則啟動影像串流
	if(wvs_status=='off')
	{
		exec = require('child_process').exec;
		web_vs = exec('python3 ./web-vs-server.py', shell=false);
		wvs_pid = web_vs.pid+1;
		console.log('pid='+wvs_pid);
		
		// 將pid of Web Video Streaming存入檔案中
		fs = require('fs');
		fs.writeFileSync('./wvs-pid.txt', wvs_pid); 
		
		// 將on存入Web Video Streaming的狀態檔中
		fs = require('fs');
		fs.writeFileSync('./wvs-status.txt', 'on'); 
		console.log('The pid and status of web video streaming is saved!');
	}
	// 然後顯示遠端監控網頁
	res.render('remotecontrol', reply_obj);
});

//*********************************************************************************************
//**************************** 進行數學加減乘除4則運算之服務方法 ******************************
//*********************************************************************************************
// 建立(附加)一個客戶端對應用程式提出 POST /math/:num1/:num2/:op 方法時的路由處理方法(匿名式函數)
// 比照此方式，你可以建立其他POST不同路徑的路由處理方法
router.post('/math/:num1/:num2/:op', function(req, res){
	var n1 = Number(req.params.num1);
	var	n2 = Number(req.params.num2);
	var op = req.params.op;
	if(op=='1') 
		value = n1 + n2;
	else if (op=='2')
		value = n1 - n2;
	else if (op=='3')
		value = n1 * n2;
	else
	{
		value = n1 / n2;
		value = value.toFixed(2); //限制小數點後只顯示2位
	}
	res.send( //傳回一個包含3個鍵值對(key-value)的JSON格式資料給用戶端
		{
			result: value
		}
	);
});

//*********************************************************************************************
//*********************************** 產生樂透號碼之服務方法 **********************************
//*********************************************************************************************
// 建立(附加)一個客戶端對應用程式提出 POST /lottery/:type/:num 方法時的路由處理方法(匿名式函數)
// 比照此方式，你可以建立其他POST不同路徑的路由處理方法
router.post('/lottery/:type/:times', function(req, res){
	var type = Number(req.params.type);
	var	times = Number(req.params.times);
	
	// 引用相同目錄(routes)下的lottery.js
	var lottery = require("./lottery.js");
	var value = lottery.GenLotteryNum(type, times);
	res.set(
		{
			'charset': 'utf-8'  // 設定回傳結果之編碼為utf-8，網頁端才能正常顯示中文
		});
	res.send( //傳回一個包含3個鍵值對(key-value)的JSON格式資料給用戶端
		{
			result: value
		}		
	);
});

//*****************************************************************************************
//*********************** 使用Yahoo API查詢天氣狀況之服務方法 *****************************
//*****************************************************************************************
// 建立(附加)一個客戶端對應用程式提出 POST /weather/:woeid 方法時的路由處理方法(匿名式函數)
// 比照此方式，你可以建立其他POST不同路徑的路由處理方法
router.post('/weather/:woeid', function(req, res){
	woeid=req.params.woeid;
	console.log(woeid);
	// 引用相同目錄(routes)下的ywq-json.js
	var ywq = require('./ywq-json.js');
	ywq.ywq_json(woeid, handle_citydata);
	
	// define the callback function the for the function ywq_json(woeid, cb)
	function handle_citydata(city_data){
		res.send(city_data);	
	}
});

//**************************************************************************************************
//************************* 啟動與關閉即時網頁視訊串流之服務方法 ***********************************
//**************************************************************************************************
// 建立(附加)一個客戶端對應用程式提出 POST /web_video_streaming/:cmd 方法時的路由處理方法(匿名式函數)
// 比照此方式，你可以建立其他POST不同路徑的路由處理方法
router.post('/web_video_streaming/:cmd', function(req, res){
	cmd=req.params.cmd;
	if(cmd=='on')
	{
		// 讀取Web Video Streaming的狀態
		fs=require('fs');
		wvs_status = fs.readFileSync('./wvs-status.txt','utf8'); 
		
		//
		if(wvs_status=='off')
		{
			exec = require('child_process').exec;
			web_vs = exec('python3 ./web-vs-server.py', shell=false);
			wvs_pid = web_vs.pid+1;
			console.log('pid='+wvs_pid);
			
			// 將pid of Web Video Streaming存入檔案中
			fs = require('fs');
			fs.writeFileSync('./wvs-pid.txt', wvs_pid); 
			
			// 將on存入Web Video Streaming的狀態檔中
			fs = require('fs');
			fs.writeFileSync('./wvs-status.txt', 'on'); 
			console.log('The pid and status of web video streaming is saved!');
		}
		// 回傳訊息給網頁端
		message={'message':'網頁即時影像串流已經開啟!'};
		res.set({
			'charset': 'utf-8'  // 設定回傳結果之編碼為utf-8，網頁端才能正常顯示中文
		});
		res.send(message);
	}
  
	if(cmd=='off') 
	{
		// 讀取Web Video Streaming的狀態
		fs=require('fs');
		wvs_status=fs.readFileSync('./wvs-status.txt','utf8');
		
		//
		if(wvs_status=='on')
		{
			// 讀取pid of Web Video Streaming
			fs=require('fs');
			wvs_pid=fs.readFileSync('./wvs-pid.txt','utf8');
			
			// 透過pid關閉(殺掉)Web Video Streaming
			exec = require('child_process').exec;
			exec('sudo kill ' + wvs_pid);
			console.log('The ' + wvs_pid + ' process is killed!');
			
			// 將off存入Web Video Streaming的狀態檔中
			fs = require('fs');
			fs.writeFileSync('./wvs-status.txt', 'off');
		}
			
		// 回傳訊息給網頁端
		message={'message':'網頁即時影像串流已經關閉!'};
		res.set({
			'charset': 'utf-8'  // 設定回傳結果之編碼為utf-8，網頁端才能正常顯示中文
		});
		res.send(message);
	}
});

//********************************************************************************************
//********************************* 控制LED之服務方法 ****************************************
//********************************************************************************************
// 建立(附加)一個客戶端對應用程式提出 POST /control_leds/:cmd 方法時的路由處理方法(匿名式函數)
// 比照此方式，你可以建立其他POST不同路徑的路由處理方法
router.post('/control_leds/:cmd', function(req, res){
	cmd=req.params.cmd;
	flag = true;
	if(cmd=="1") 
		message = {"message":"奇數LED燈正在閃爍!"};
	else if (cmd=="2") 
		message = {"message":"偶數LED燈正在閃爍!"};
	else if(cmd=="3") 
		message = {"message":"正用PWM驅動LED燈!"};
	else if (cmd=="4")
	{
		message = {"message":"LED正在執行跑馬燈!"};
	}
	else
	{
		flag = false;
		message = {"message":"無效的命令!"};
	}
	res.set({
	  'charset': 'utf-8'  // 設定回傳結果之編碼為utf-8，網頁端才能正常顯示中文
	});
	res.send(message);
	
	if(flag)
	{
		var PythonShell = require('python-shell');
		var options = {
				mode: 'json',
				scriptPath: './',
				args: [cmd]
			};
		
		PythonShell.run('control-leds.py', options, function(err, results){
			if(err) console.log(err);
		});
	}
});


//*************************************************************************************
//*************************** 控制Arduino之服務方法 ***************************
//*************************************************************************************
// 建立(附加)一個客戶端對應用程式提出 POST /read_dht11 方法時的路由處理方法(匿名式函數)
// 比照此方式，你可以建立其他POST不同路徑的路由處理方法
router.post('/control_arduino/:cmd', function(req, res){
	cmd=req.params.cmd;
	console.log(cmd);
	var count = 0;
	var result = [];
	if(!serialport.isOpen())
	{
		serialport.open(function (err) {
		if (err) 
			console.log('Error: ', err.message);
		else
			console.log("Serial Port is opened"); 
		});
	}
	//
	serialport.write(cmd); // non-blocking
	serialport.drain(); // Waits until all output data has been transmitted to the serial port
	//
	serialport.on("data", readSerialData); 
	
	function readSerialData(data)
	{
		try
		{
			if(count==0)
			{
				count++;
				console.log("count: " + count);
				result = data.split(','); // split the string into an array
				console.log("The command is: ", result[0]); // result[0] is the command
				if(result[0]=='4') // if the command is '4', 
				{
					var temperature = result[1]; // result[1] is temperature 
					var humidity = result[2];    // result[2] is humidity
					console.log("Temperature: ", temperature); // Here, just print the result.
					console.log("Humidity: ", humidity);        
				}
				else
				{
					result.push(0);
					result.push(0);
				}
				message = {"cmd": cmd, "value1":result[1], "value2":result[2]};	
				console.log(message);
				res.send(message);
			}
		}
		catch(ex)
		{
			//console.log(ex.message);
			//message = {"cmd":cmd, "value1":"", "value2":""}
			//res.send(message);
		}
	}
});

module.exports = router;
